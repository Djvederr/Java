Picture Project
===========

Picture CS Project

<h3>About the project</h3>
This project is the last lab for computer science, first semester.

<h3>Usage</h3>
This project works best on [BlueJ](http://www.bluej.org/). Simply load the classes folder onto BlueJ, and it should be ready to compile.

<h3>License</h3>
This project is protected by the [MIT license](https://github.com/jacksonchen/Picture-Project/blob/master/LICENSE.md). If you use our code, please attribute us.

<h3>Contributors</h3>
 - Jackson Chen
 - Will Kaufman
